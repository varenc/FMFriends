from fmfriends.fmfriends import FMFException, FMF
